# Orbital Guide — Android Studio starter project

A prototype floating overlay and accessibility-driven tap helper for the high-contrast orbit game shown in the supplied screenshot.

## What it currently attempts

- Draws a persistent, touch-through guide ray from the detected white front marker of the largest dark on-screen character.
- Captures the screen only after Android shows its screen-capture consent prompt.
- Lets you drag the orange target reticle onto the center of the next target circle. Auto-tap stays blocked until the reticle has been moved at least once.
- When auto-tap is explicitly switched on, compares the detected character direction with the manually marked target direction and requests one tap after two consecutive aligned frames. It latches to prevent continuous repeated tapping.
- If the tracker cannot find the character/front marker, the guide reports `NO TRACK LOCK` and auto-tapping does not run on that frame.

## Important limits

This is an experimental prototype, not a verified game bot. Its visual detector is tuned to the reference screenshot's high-contrast black character with an enclosed white front marker. Effects, animations, scaling, new levels, UI changes, another screen aspect ratio, or compression may cause it to lose lock or estimate the wrong direction. It does **not** yet identify the next target circle automatically; the orange target reticle is calibrated by dragging it onto the intended circle. The tap is dispatched at screen center because this game appears to accept a tap anywhere, but that assumption must be tested on the device. Auto-tap is off by default.

Do not leave auto-tap on before testing alignment with the game paused or in a safe attempt. A screenshot cannot prove pixel-perfect tracking across motion, so test with the guide only and tune/calibrate before enabling tapping.

## Build

1. Open this folder in Android Studio (recent version with Android SDK 35 installed).
2. Let Android Studio sync the Gradle project and install any requested SDK components.
3. Build with **Build > Build APK(s)**. The generated APK will appear under `app/build/outputs/apk/debug/`.
4. Install the debug APK on your Android device. Android may require allowing installation from the app you use to open the APK.

This environment did not have the Android SDK/Gradle installed, so the project source has not been compiled into an APK here.

## First run

1. Open Orbital Guide and tap **Allow overlay and show guide**. Enable “Display over other apps” in Android settings and return.
2. Tap **Start live screen tracking** and approve Android's screen-capture prompt.
3. In Android Accessibility settings, enable **Orbital Guide Auto Tap**. This is required only for automated taps.
4. Return to the game. Drag the orange reticle onto the center of the circle you want to reach. The guide ray should follow the detected white front marker.
5. Leave `AUTO TAP: OFF` until line tracking looks right. Tap the floating `AUTO TAP: OFF` pill only when ready to test.
6. Tap **Stop live tracking** / **Remove floating overlay** in the main app to stop the respective components.

## Permissions / privacy

- `SYSTEM_ALERT_WINDOW`: displays the guide and calibration controls above the game.
- `MediaProjection`: captures live screen frames for local visual analysis; Android shows a system consent prompt and a persistent notification.
- Accessibility gesture permission: dispatches the tap only when auto-tap is on and alignment is detected.

Frames are processed locally in the app. No network upload is implemented.
