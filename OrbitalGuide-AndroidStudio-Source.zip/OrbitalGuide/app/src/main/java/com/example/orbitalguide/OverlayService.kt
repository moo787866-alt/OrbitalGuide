package com.example.orbitalguide

import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var guideView: GuideCanvasView? = null
    private var targetView: TargetHandleView? = null
    private var controlView: TextView? = null
    private var targetParams: WindowManager.LayoutParams? = null
    private var controlParams: WindowManager.LayoutParams? = null

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, Notifications.build(this, "Orbital Guide overlay"), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, Notifications.build(this, "Orbital Guide overlay"))
        }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showGuide()
        showTargetHandle()
        showControl()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    private fun baseParams(width: Int, height: Int, flags: Int, gravity: Int = Gravity.TOP or Gravity.START): WindowManager.LayoutParams {
        return WindowManager.LayoutParams(
            width, height,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags,
            android.graphics.PixelFormat.TRANSLUCENT
        ).apply {
            this.gravity = gravity
            x = 0
            y = 0
        }
    }

    private fun showGuide() {
        val view = GuideCanvasView(this)
        guideView = view
        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        wm.addView(view, baseParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, flags))
        currentGuide = view
    }

    private fun showTargetHandle() {
        val dm = resources.displayMetrics
        val side = (48 * dm.density).toInt()
        val view = TargetHandleView(this)
        targetView = view
        val params = baseParams(side, side,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN)
        targetParams = params
        placeTargetHandle()
        wm.addView(view, params)
        // placeTargetHandle() needs the actual params after the view has been attached.
        placeTargetHandle()

        view.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.lastRawX = event.rawX
                    view.lastRawY = event.rawY
                    view.startX = params.x
                    view.startY = params.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val newX = (view.startX + event.rawX - view.lastRawX).toInt()
                    val newY = (view.startY + event.rawY - view.lastRawY).toInt()
                    params.x = newX.coerceIn(0, screenWidth() - side)
                    params.y = newY.coerceIn(0, screenHeight() - side)
                    try { wm.updateViewLayout(view, params) } catch (_: Exception) { }
                    val cx = (params.x + side / 2f) / screenWidth().coerceAtLeast(1)
                    val cy = (params.y + side / 2f) / screenHeight().coerceAtLeast(1)
                    Settings.setTarget(this, cx, cy)
                    true
                }
                else -> true
            }
        }
    }

    private fun placeTargetHandle() {
        val params = targetParams ?: return
        val side = params.width
        params.x = (Settings.targetX(this) * screenWidth() - side / 2f).toInt().coerceAtLeast(0)
        params.y = (Settings.targetY(this) * screenHeight() - side / 2f).toInt().coerceAtLeast(0)
    }

    private fun showControl() {
        val dm = resources.displayMetrics
        val pad = (12 * dm.density).toInt()
        val view = TextView(this).apply {
            textSize = 12.5f
            setTextColor(Color.WHITE)
            setPadding(pad, pad / 2, pad, pad / 2)
            setBackgroundColor(0xD92A3339.toInt())
            text = autoLabel()
            contentDescription = "Tap to turn target auto-tap on or off"
        }
        controlView = view
        val params = baseParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN)
        params.x = (12 * dm.density).toInt()
        params.y = (78 * dm.density).toInt()
        controlParams = params
        wm.addView(view, params)
        var downX = 0f
        var downY = 0f
        var originX = params.x
        var originY = params.y
        var moved = false
        view.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    originX = params.x
                    originY = params.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downX
                    val dy = event.rawY - downY
                    if (kotlin.math.abs(dx) > dm.density * 5 || kotlin.math.abs(dy) > dm.density * 5) moved = true
                    if (moved) {
                        params.x = (originX + dx).toInt().coerceIn(0, screenWidth() - view.width)
                        params.y = (originY + dy).toInt().coerceIn(0, screenHeight() - view.height)
                        try { wm.updateViewLayout(view, params) } catch (_: Exception) { }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        Settings.setAutoEnabled(this, !Settings.autoEnabled(this))
                        view.text = autoLabel()
                    }
                    true
                }
                else -> true
            }
        }
    }

    private fun autoLabel() = if (Settings.autoEnabled(this)) "AUTO TAP: ON" else "AUTO TAP: OFF"

    private fun screenWidth(): Int {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(metrics)
        return metrics.widthPixels.coerceAtLeast(1)
    }

    private fun screenHeight(): Int {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(metrics)
        return metrics.heightPixels.coerceAtLeast(1)
    }

    override fun onDestroy() {
        if (currentGuide === guideView) currentGuide = null
        try { guideView?.let { wm.removeView(it) } } catch (_: Exception) { }
        try { targetView?.let { wm.removeView(it) } } catch (_: Exception) { }
        try { controlView?.let { wm.removeView(it) } } catch (_: Exception) { }
        guideView = null
        targetView = null
        controlView = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val NOTIFICATION_ID = 4201
        @Volatile private var currentGuide: GuideCanvasView? = null
        @Volatile private var latestFrame: TrackingFrame? = null
        @Volatile private var lockLost = true

        fun updateTracking(frame: TrackingFrame) {
            latestFrame = frame
            lockLost = false
            currentGuide?.postInvalidate()
        }

        fun setTrackingLost() {
            lockLost = true
            currentGuide?.postInvalidate()
        }

        fun trackingFrame(): TrackingFrame? = if (lockLost) null else latestFrame
    }
}

private class GuideCanvasView(context: android.content.Context) : View(context) {
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF00CFA6.toInt()
        strokeWidth = 3.0f * resources.displayMetrics.density
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val haloPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xDFFFFFFF.toInt()
        strokeWidth = 7.0f * resources.displayMetrics.density
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val markerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF00CFA6.toInt()
        strokeWidth = 2.0f * resources.displayMetrics.density
        style = Paint.Style.STROKE
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xE6007F68.toInt()
        textSize = 12.0f * resources.displayMetrics.density
        style = Paint.Style.FILL
        typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val frame = OverlayService.trackingFrame()
        if (frame == null || System.currentTimeMillis() - frame.timestampMs > 500) {
            canvas.drawText("NO TRACK LOCK", 18f * resources.displayMetrics.density, height - 26f * resources.displayMetrics.density, textPaint)
            return
        }
        val sx = width.toFloat() / frame.width.coerceAtLeast(1)
        val sy = height.toFloat() / frame.height.coerceAtLeast(1)
        val x = frame.noseX * sx
        val y = frame.noseY * sy
        val dx = frame.noseX - frame.bodyX
        val dy = frame.noseY - frame.bodyY
        val mag = kotlin.math.hypot(dx, dy).coerceAtLeast(0.001f)
        val ux = dx / mag
        val uy = dy / mag
        val length = 185f * resources.displayMetrics.density
        val ex = x + ux * length
        val ey = y + uy * length
        canvas.drawLine(x, y, ex, ey, haloPaint)
        canvas.drawLine(x, y, ex, ey, linePaint)
        canvas.drawCircle(x, y, 7f * resources.displayMetrics.density, markerPaint)
        canvas.drawLine(x - 10f, y, x + 10f, y, markerPaint)
        canvas.drawLine(x, y - 10f, x, y + 10f, markerPaint)
    }
}

private class TargetHandleView(context: android.content.Context) : View(context) {
    var lastRawX = 0f
    var lastRawY = 0f
    var startX = 0
    var startY = 0
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFA600.toInt()
        strokeWidth = 2.5f * resources.displayMetrics.density
        style = Paint.Style.STROKE
    }
    private val crossPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFA600.toInt()
        strokeWidth = 1.7f * resources.displayMetrics.density
        style = Paint.Style.STROKE
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val radius = minOf(width, height) * 0.34f
        canvas.drawCircle(cx, cy, radius, ringPaint)
        canvas.drawCircle(cx, cy, radius * 0.35f, ringPaint)
        canvas.drawLine(cx - radius * 1.4f, cy, cx + radius * 1.4f, cy, crossPaint)
        canvas.drawLine(cx, cy - radius * 1.4f, cx, cy + radius * 1.4f, crossPaint)
    }
}
