package com.example.orbitalguide

import java.nio.ByteBuffer
import kotlin.math.max
import kotlin.math.min

/**
 * Lightweight frame tracker for this game's high-contrast character.
 * It finds the largest connected dark component, then searches inside its
 * bounding box for an enclosed bright component (the white front marker).
 */
class ScreenTracker {
    data class Detection(val frame: TrackingFrame, val confidence: Float)

    fun analyze(buffer: ByteBuffer, width: Int, height: Int, rowStride: Int, pixelStride: Int): Detection? {
        if (width < 100 || height < 200) return null
        val scale = 2
        val sw = width / scale
        val sh = height / scale
        val count = sw * sh
        if (count <= 0) return null

        val gray = ByteArray(count)
        val dark = BooleanArray(count)
        val source = buffer.duplicate()
        for (y in 0 until sh) {
            val sy = y * scale
            val base = sy * rowStride
            for (x in 0 until sw) {
                val sx = x * scale
                val p = base + sx * pixelStride
                if (p + 2 >= source.limit()) continue
                val r = source.get(p).toInt() and 0xFF
                val g = source.get(p + 1).toInt() and 0xFF
                val b = source.get(p + 2).toInt() and 0xFF
                val lum = ((299 * r + 587 * g + 114 * b) / 1000).coerceIn(0, 255)
                gray[y * sw + x] = lum.toByte()
                dark[y * sw + x] = lum < 76
            }
        }

        val visited = BooleanArray(count)
        val queue = IntArray(count)
        var bestSize = 0
        var bestPixels: IntArray? = null
        var bestMinX = 0
        var bestMaxX = 0
        var bestMinY = 0
        var bestMaxY = 0
        var bestSumX = 0L
        var bestSumY = 0L

        // Components are found with 8-neighbour connectivity. Small dot clusters are filtered by area.
        for (start in 0 until count) {
            if (!dark[start] || visited[start]) continue
            var head = 0
            var tail = 0
            queue[tail++] = start
            visited[start] = true
            var minX = sw
            var maxX = 0
            var minY = sh
            var maxY = 0
            var sumX = 0L
            var sumY = 0L
            while (head < tail) {
                val idx = queue[head++]
                val x = idx % sw
                val y = idx / sw
                if (x < minX) minX = x
                if (x > maxX) maxX = x
                if (y < minY) minY = y
                if (y > maxY) maxY = y
                sumX += x
                sumY += y
                val y0 = max(0, y - 1)
                val y1 = min(sh - 1, y + 1)
                val x0 = max(0, x - 1)
                val x1 = min(sw - 1, x + 1)
                for (ny in y0..y1) for (nx in x0..x1) {
                    val ni = ny * sw + nx
                    if (dark[ni] && !visited[ni]) {
                        visited[ni] = true
                        queue[tail++] = ni
                    }
                }
            }
            val boxW = maxX - minX + 1
            val boxH = maxY - minY + 1
            if (tail > bestSize && tail >= 55 && boxW >= 11 && boxH >= 10) {
                bestSize = tail
                bestPixels = queue.copyOf(tail)
                bestMinX = minX
                bestMaxX = maxX
                bestMinY = minY
                bestMaxY = maxY
                bestSumX = sumX
                bestSumY = sumY
            }
        }

        val bodyPixels = bestPixels ?: return null
        if (bestSize < 55) return null
        val bodyCx = bestSumX.toFloat() / bestSize
        val bodyCy = bestSumY.toFloat() / bestSize

        // Flood-fill bright components inside the character crop. The screen background
        // touches the crop border and is discarded, leaving enclosed white details such as the front ring.
        val pad = 3
        val cropX0 = max(0, bestMinX - pad)
        val cropX1 = min(sw - 1, bestMaxX + pad)
        val cropY0 = max(0, bestMinY - pad)
        val cropY1 = min(sh - 1, bestMaxY + pad)
        val cw = cropX1 - cropX0 + 1
        val ch = cropY1 - cropY0 + 1
        val cropCount = cw * ch
        val whiteSeen = BooleanArray(cropCount)
        val whiteQueue = IntArray(cropCount)
        var bestWhiteArea = 0
        var bestNoseX = Float.NaN
        var bestNoseY = Float.NaN

        for (localStart in 0 until cropCount) {
            if (whiteSeen[localStart]) continue
            val gx = cropX0 + localStart % cw
            val gy = cropY0 + localStart / cw
            val global = gy * sw + gx
            val lum = gray[global].toInt() and 0xFF
            if (lum < 195) {
                whiteSeen[localStart] = true
                continue
            }
            var head = 0
            var tail = 0
            whiteQueue[tail++] = localStart
            whiteSeen[localStart] = true
            var sX = 0L
            var sY = 0L
            var touchesEdge = false
            while (head < tail) {
                val loc = whiteQueue[head++]
                val lx = loc % cw
                val ly = loc / cw
                if (lx == 0 || ly == 0 || lx == cw - 1 || ly == ch - 1) touchesEdge = true
                val ax = cropX0 + lx
                val ay = cropY0 + ly
                sX += ax
                sY += ay
                for (ny in max(0, ly - 1)..min(ch - 1, ly + 1)) {
                    for (nx in max(0, lx - 1)..min(cw - 1, lx + 1)) {
                        val nLoc = ny * cw + nx
                        if (whiteSeen[nLoc]) continue
                        val nLum = gray[(cropY0 + ny) * sw + cropX0 + nx].toInt() and 0xFF
                        if (nLum >= 195) {
                            whiteSeen[nLoc] = true
                            whiteQueue[tail++] = nLoc
                        } else {
                            whiteSeen[nLoc] = true
                        }
                    }
                }
            }
            // The front marker's white center is small, fully enclosed, and offset from the black body's centroid.
            if (!touchesEdge && tail in 2..80 && tail > bestWhiteArea) {
                val nx = sX.toFloat() / tail
                val ny = sY.toFloat() / tail
                if (nx >= bestMinX && nx <= bestMaxX && ny >= bestMinY && ny <= bestMaxY) {
                    bestWhiteArea = tail
                    bestNoseX = nx
                    bestNoseY = ny
                }
            }
        }

        if (bestWhiteArea < 2 || bestNoseX.isNaN() || bestNoseY.isNaN()) return null
        val separation = kotlin.math.hypot(bestNoseX - bodyCx, bestNoseY - bodyCy)
        if (separation < 2.5f) return null

        val frame = TrackingFrame(
            bodyX = bodyCx * scale,
            bodyY = bodyCy * scale,
            noseX = bestNoseX * scale,
            noseY = bestNoseY * scale,
            width = width,
            height = height,
            timestampMs = System.currentTimeMillis()
        )
        val fillConfidence = (bestSize / 350f).coerceIn(0.35f, 1f)
        return Detection(frame, fillConfidence)
    }
}
