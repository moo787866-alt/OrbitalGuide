package com.example.orbitalguide

import android.content.Context
import android.content.SharedPreferences
import kotlin.math.abs

object Settings {
    private const val FILE = "orbital_guide_settings"
    private fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun autoEnabled(context: Context) = prefs(context).getBoolean("auto_enabled", false)
    fun setAutoEnabled(context: Context, value: Boolean) =
        prefs(context).edit().putBoolean("auto_enabled", value).apply()

    fun targetX(context: Context) = prefs(context).getFloat("target_x", 0.64f)
    fun targetY(context: Context) = prefs(context).getFloat("target_y", 0.63f)
    fun targetCalibrated(context: Context) = prefs(context).getBoolean("target_calibrated", false)
    fun setTarget(context: Context, x: Float, y: Float) {
        prefs(context).edit()
            .putFloat("target_x", x.coerceIn(0.02f, 0.98f))
            .putFloat("target_y", y.coerceIn(0.04f, 0.96f))
            .putBoolean("target_calibrated", true)
            .apply()
    }

    fun tapThresholdDegrees(context: Context) =
        prefs(context).getFloat("threshold_degrees", 7f).coerceIn(3f, 15f)

    fun screenW(context: Context) = prefs(context).getInt("screen_w", 0)
    fun screenH(context: Context) = prefs(context).getInt("screen_h", 0)
    fun setScreenSize(context: Context, w: Int, h: Int) {
        prefs(context).edit().putInt("screen_w", w).putInt("screen_h", h).apply()
    }
}

data class TrackingFrame(
    val bodyX: Float,
    val bodyY: Float,
    val noseX: Float,
    val noseY: Float,
    val width: Int,
    val height: Int,
    val timestampMs: Long
) {
    val angleRadians: Float
        get() = kotlin.math.atan2(noseY - bodyY, noseX - bodyX)
}

fun angleDistance(a: Float, b: Float): Float {
    var d = (a - b + Math.PI.toFloat()) % (2f * Math.PI.toFloat())
    if (d < 0f) d += 2f * Math.PI.toFloat()
    return abs(d - Math.PI.toFloat())
}
