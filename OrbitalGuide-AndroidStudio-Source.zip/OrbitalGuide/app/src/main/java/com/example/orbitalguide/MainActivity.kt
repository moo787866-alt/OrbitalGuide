package com.example.orbitalguide

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val requestOverlay = 701
    private val requestCapture = 702

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(245, 247, 248)
        window.navigationBarColor = android.graphics.Color.rgb(245, 247, 248)
        buildScreen()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.TOP
            setPadding(dp(22), dp(24), dp(22), dp(24))
            setBackgroundColor(android.graphics.Color.rgb(245, 247, 248))
        }
        root.addView(TextView(this).apply {
            text = "ORBITAL GUIDE"
            textSize = 25f
            setTextColor(android.graphics.Color.rgb(22, 34, 42))
            letterSpacing = 0.08f
        }, matchWidth())
        root.addView(TextView(this).apply {
            text = "Floating front guide • live screen tracking • alignment-triggered tap"
            textSize = 15f
            setTextColor(android.graphics.Color.rgb(77, 90, 98))
            setPadding(0, dp(8), 0, dp(16))
        }, matchWidth())

        addButton(root, "1  •  Allow overlay and show guide") { requestOverlayAndStart() }
        addButton(root, "2  •  Start live screen tracking") { requestScreenCapture() }
        addButton(root, "3  •  Enable Android auto-tap service") {
            startActivity(Intent(AndroidSettings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        addButton(root, if (SettingsCompat.autoEnabled(this)) "AUTO-TAP: ON" else "AUTO-TAP: OFF (recommended)") {
            val next = !SettingsCompat.autoEnabled(this)
            SettingsCompat.setAutoEnabled(this, next)
            Toast.makeText(this, if (next) "Auto-tap enabled" else "Auto-tap disabled", Toast.LENGTH_SHORT).show()
            buildScreen()
        }
        addButton(root, "Stop live tracking") {
            stopService(Intent(this, CaptureService::class.java))
            Toast.makeText(this, "Tracking stopped", Toast.LENGTH_SHORT).show()
        }
        addButton(root, "Remove floating overlay") {
            stopService(Intent(this, OverlayService::class.java))
        }
        root.addView(TextView(this).apply {
            text = "CALIBRATION\nDrag the small target ring onto the next circle. The overlay guide follows the detected black character and its enclosed white front marker. Test with auto-tap OFF first. Tracking is visual and may lose lock during transitions; this is an experimental helper, not a guarantee of perfect play."
            textSize = 14f
            setLineSpacing(dp(3).toFloat(), 1f)
            setTextColor(android.graphics.Color.rgb(63, 75, 83))
            setPadding(0, dp(16), 0, 0)
        }, matchWidth())
        setContentView(root)
    }

    private fun requestOverlayAndStart() {
        if (!AndroidSettings.canDrawOverlays(this)) {
            val intent = Intent(AndroidSettings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            @Suppress("DEPRECATION")
            startActivityForResult(intent, requestOverlay)
        } else {
            startOverlay()
        }
    }

    private fun startOverlay() {
        if (!AndroidSettings.canDrawOverlays(this)) {
            Toast.makeText(this, "Overlay permission is required", Toast.LENGTH_LONG).show()
            return
        }
        val intent = Intent(this, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        Toast.makeText(this, "Guide shown. Drag the target ring to calibrate.", Toast.LENGTH_LONG).show()
    }

    private fun requestScreenCapture() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(manager.createScreenCaptureIntent(), requestCapture)
    }

    @Deprecated("Kept for broad Android compatibility in this starter project")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            requestOverlay -> if (AndroidSettings.canDrawOverlays(this)) startOverlay()
            requestCapture -> {
                if (resultCode == RESULT_OK && data != null) {
                    val service = Intent(this, CaptureService::class.java).apply {
                        putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                        putExtra(CaptureService.EXTRA_RESULT_DATA, data)
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service) else startService(service)
                    Toast.makeText(this, "Screen tracking started; switch back to the game.", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, "Screen-capture permission was not granted", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun addButton(root: LinearLayout, label: String, action: () -> Unit) {
        root.addView(Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 15f
            setOnClickListener { action() }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)).apply {
            bottomMargin = dp(8)
        })
    }

    private fun matchWidth() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}

// Kept separate from android.provider.Settings to make the screen code easy to read.
private object SettingsCompat {
    fun autoEnabled(context: android.content.Context) = com.example.orbitalguide.Settings.autoEnabled(context)
    fun setAutoEnabled(context: android.content.Context, enabled: Boolean) = com.example.orbitalguide.Settings.setAutoEnabled(context, enabled)
}
