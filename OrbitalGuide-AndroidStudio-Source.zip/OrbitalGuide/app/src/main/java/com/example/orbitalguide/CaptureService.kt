package com.example.orbitalguide

import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import kotlin.math.atan2

class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var worker: Handler? = null
    private val tracker = ScreenTracker()
    private var lastAnalyzeAt = 0L
    private var consecutiveMisses = 0
    private var consecutiveAligned = 0
    private var latched = false
    private var lastTargetX = Float.NaN
    private var lastTargetY = Float.NaN
    private var lastTapAt = 0L

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // The media-projection session must be foreground before getMediaProjection() on modern Android.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, Notifications.build(this, "Orbital Guide screen tracking"), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIFICATION_ID, Notifications.build(this, "Orbital Guide screen tracking"))
        }

        if (projection != null) return START_STICKY
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        @Suppress("DEPRECATION")
        val resultData: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            intent?.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
        }
        if (resultCode == 0 || resultData == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, resultData)
            setupCapture()
        } catch (_: Exception) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun setupCapture() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels.coerceAtLeast(1)
        val height = metrics.heightPixels.coerceAtLeast(1)
        Settings.setScreenSize(this, width, height)
        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 3)
        thread = HandlerThread("OrbitalGuideFrameAnalyzer").also { it.start() }
        worker = Handler(thread!!.looper)
        imageReader!!.setOnImageAvailableListener({ reader ->
            val now = System.currentTimeMillis()
            if (now - lastAnalyzeAt < 55) {
                reader.acquireLatestImage()?.close()
                return@setOnImageAvailableListener
            }
            lastAnalyzeAt = now
            val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val plane = image.planes.firstOrNull() ?: return@setOnImageAvailableListener
                val detection = tracker.analyze(plane.buffer, image.width, image.height, plane.rowStride, plane.pixelStride)
                if (detection != null && detection.confidence >= 0.35f) {
                    consecutiveMisses = 0
                    OverlayService.updateTracking(detection.frame)
                    handleAlignment(detection.frame)
                } else {
                    consecutiveAligned = 0
                    consecutiveMisses++
                    // Brief visual misses do not flicker the guide. Three misses lose lock and prevent new taps.
                    if (consecutiveMisses >= 3) OverlayService.setTrackingLost()
                }
            } finally {
                image.close()
            }
        }, worker)

        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopSelf()
            }
        }, worker)

        virtualDisplay = projection?.createVirtualDisplay(
            "OrbitalGuideCapture", width, height, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader!!.surface, null, worker
        )
    }

    private fun handleAlignment(frame: TrackingFrame) {
        if (!Settings.autoEnabled(this) || !Settings.targetCalibrated(this)) {
            consecutiveAligned = 0
            latched = false
            return
        }
        val targetXn = Settings.targetX(this)
        val targetYn = Settings.targetY(this)
        if (lastTargetX.isNaN() || kotlin.math.abs(targetXn - lastTargetX) > 0.006f || kotlin.math.abs(targetYn - lastTargetY) > 0.006f) {
            latched = false
            consecutiveAligned = 0
            lastTargetX = targetXn
            lastTargetY = targetYn
        }
        val targetX = targetXn * frame.width
        val targetY = targetYn * frame.height
        // Compare the target direction from the white front marker against the detected body-to-front direction.
        val dx = targetX - frame.noseX
        val dy = targetY - frame.noseY
        val targetAngle = atan2(dy, dx)
        val difference = angleDistance(frame.angleRadians, targetAngle)
        val threshold = Math.toRadians(Settings.tapThresholdDegrees(this).toDouble()).toFloat()
        if (difference <= threshold) {
            consecutiveAligned++
            if (consecutiveAligned >= 2 && !latched && System.currentTimeMillis() - lastTapAt > 650) {
                // Latch first so a slow or unavailable accessibility service cannot generate rapid repeats.
                latched = true
                lastTapAt = System.currentTimeMillis()
                TapAccessibilityService.tapCenterIfEnabled()
            }
        } else {
            consecutiveAligned = 0
            if (difference > Math.toRadians(15.0).toFloat()) latched = false
        }
    }

    override fun onDestroy() {
        try { imageReader?.setOnImageAvailableListener(null, null) } catch (_: Exception) { }
        virtualDisplay?.release()
        imageReader?.close()
        projection?.stop()
        thread?.quitSafely()
        virtualDisplay = null
        imageReader = null
        projection = null
        thread = null
        worker = null
        OverlayService.setTrackingLost()
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val EXTRA_RESULT_CODE = "projection_result_code"
        const val EXTRA_RESULT_DATA = "projection_result_data"
        private const val NOTIFICATION_ID = 4202
    }
}
